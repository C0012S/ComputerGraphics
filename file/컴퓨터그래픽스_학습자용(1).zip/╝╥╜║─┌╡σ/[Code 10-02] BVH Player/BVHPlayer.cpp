#include <windows.h>
#include <gl/glut.h>
#include "BVH.h"

static float   camera_yaw = 0.0f;
static float   camera_pitch = -20.0f;
static float   camera_distance = 10.0f;

static int     drag_mouse_r = 0;
static int     drag_mouse_l = 0;
static int     last_mouse_x, last_mouse_y;

bool	on_animation = true;
float	animation_time = 0.0f;
int		frame_no = 0;
BVH		*bvh = NULL;

void MyDisplay() {
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );
    glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	glTranslatef( 0.0, 0.0, - camera_distance );
	glRotatef( - camera_pitch, 1.0, 0.0, 0.0 );
	glRotatef( - camera_yaw, 0.0, 1.0, 0.0 );
	glTranslatef( 0.0, -0.5, 0.0 );

	float  light0_position[] = { 10.0, 10.0, 10.0, 1.0 };
	glLightfv( GL_LIGHT0, GL_POSITION, light0_position );

	float  size = 1.5f;
	int  num_x = 10, num_z = 10;
	double  ox, oz;

	glBegin( GL_QUADS );
		glNormal3d( 0.0, 1.0, 0.0 );
		ox = -(num_x * size) / 2;
		for ( int x=0; x<num_x; x++, ox+=size ) {
			oz = -(num_z * size) / 2;
			for ( int z=0; z<num_z; z++, oz+=size ) {
				if ( ((x + z) % 2) == 0 )
					glColor3f( 0.5, 0.5, 0.5 );
				else
					glColor3f( 1.0, 1.0, 1.0 );
				glVertex3d( ox, 0.0, oz );
				glVertex3d( ox, 0.0, oz+size );
				glVertex3d( ox+size, 0.0, oz+size );
				glVertex3d( ox+size, 0.0, oz );
			}
		}
	glEnd();

	glColor3f( 1.0f, 0.0f, 0.0f );

	if ( bvh ) bvh->RenderFigure( frame_no, 0.02f );

    glutSwapBuffers();
}

void MyReshape( int w, int h ) {
    glViewport(0, 0, w, h);	
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    gluPerspective( 45, (double)w/h, 1, 500 );
}

void MyMouse( int button, int state, int mx, int my ) {
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN) {
			drag_mouse_l = 1;
		 } else 
		drag_mouse_l = 0;
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         if (state == GLUT_DOWN) {
			drag_mouse_r = 1;
		 } else 
			drag_mouse_r = 0;
         break;
      default:
         break;
   }
	glutPostRedisplay();

	last_mouse_x = mx;
	last_mouse_y = my;
}

void MyMotion( int mx, int my ) {
	if ( drag_mouse_l )	{
		camera_yaw -= ( mx - last_mouse_x ) * 1.0;
		if ( camera_yaw < 0.0 )
			camera_yaw += 360.0;
		else if ( camera_yaw > 360.0 )
			camera_yaw -= 360.0;

		camera_pitch -= ( my - last_mouse_y ) * 1.0;
		if ( camera_pitch < -90.0 )
			camera_pitch = -90.0;
		else if ( camera_pitch > 90.0 )
			camera_pitch = 90.0;
	}

	if ( drag_mouse_r )	{
		camera_distance += ( my - last_mouse_y ) * 0.2;
		if ( camera_distance < 2.0 )
			camera_distance = 2.0;
	}

	last_mouse_x = mx;
	last_mouse_y = my;

	glutPostRedisplay();
}

void MyKeyboard( unsigned char key, int mx, int my ) {
	if ( key == 's' ) on_animation = !on_animation;
	else if ( ( key == 'n' ) && !on_animation ) {
		animation_time += bvh->GetInterval();
		frame_no ++;
		frame_no = frame_no % bvh->GetNumFrame();
	} else if ( ( key == 'p' ) && !on_animation && ( frame_no > 0 ) && bvh ) {
		animation_time -= bvh->GetInterval();
		frame_no --;
		frame_no = frame_no % bvh->GetNumFrame();
	} else if ( key == 'r' ) {
		animation_time = 0.0f;
		frame_no = 0;
	}

	glutPostRedisplay();
}

void  MyIdle() {
	if ( on_animation ) {
		static DWORD  last_time = 0;
		DWORD  curr_time = timeGetTime();
		
		float  delta = ( curr_time - last_time ) * 0.001f;
		if ( delta > 0.03f )	delta = 0.03f;

		last_time = curr_time;
		animation_time += delta;

		if ( bvh ) {
			frame_no = animation_time / bvh->GetInterval();
			frame_no = frame_no % bvh->GetNumFrame();
		} else
			frame_no = 0;
			
		glutPostRedisplay();
	}
}

void MyInit() {
	float  light0_position[] = { 10.0, 10.0, 10.0, 1.0 };
	float  light0_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
	float  light0_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	float  light0_ambient[] = { 0.1, 0.1, 0.1, 1.0 };

	glLightfv( GL_LIGHT0, GL_POSITION, light0_position );
	glLightfv( GL_LIGHT0, GL_DIFFUSE, light0_diffuse );
	glLightfv( GL_LIGHT0, GL_SPECULAR, light0_specular );
	glLightfv( GL_LIGHT0, GL_AMBIENT, light0_ambient );
	glEnable( GL_LIGHT0 );

	glEnable( GL_LIGHTING );
	glEnable( GL_COLOR_MATERIAL );
	glEnable( GL_DEPTH_TEST );
	glCullFace( GL_BACK );
	glEnable( GL_CULL_FACE );

	glClearColor( 0.5, 0.5, 0.8, 0.0 );

	bvh = new BVH( "back_flip.bvh" );
}

int main( int argc, char ** argv ) {
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_DOUBLE | GLUT_RGBA | GLUT_STENCIL );
	glutInitWindowSize( 800, 600 );
	glutInitWindowPosition( 0, 0 );
    glutCreateWindow("Motion Capture - BVH Player");

    glutDisplayFunc( MyDisplay );
    glutReshapeFunc( MyReshape );
	glutMouseFunc( MyMouse );
	glutMotionFunc( MyMotion );
	glutKeyboardFunc( MyKeyboard );
	glutIdleFunc( MyIdle );
	MyInit();

    glutMainLoop();
    return 0;
}

