#include <stdio.h>
#include <glut.h>
#include <glu.h>

GLfloat eyex = 1.0, eyey = 1.0, eyez = 1.5, fovy = 90.0; 

void InitLight() {
	GLfloat light0_ambient[ ] = {0.9, 0.4, 0.3, 1.0};
	GLfloat light0_diffuse[ ] = {0.8, 0.7, 0.6, 1.0};
	GLfloat light0_specular[ ] = {1.0, 1.0, 1.0, 1.0}; 

	GLfloat material_ambient[ ] = {0.4, 0.4, 0.4, 1.0};
	GLfloat material_diffuse[ ] =  {0.9, 0.9, 0.9, 1.0};
	GLfloat material_specular[ ] =  {1.0, 1.0, 1.0, 1.0}; 
	GLfloat material_shininess[ ] = {25.0};

	glShadeModel(GL_SMOOTH);	
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);						
	glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);	 
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0_specular);
}

void oglCylinder (double height, double radius) {
	height /= 2.;
 
	int slices = 15;
	GLUquadricObj *obj = gluNewQuadric();
 
	glTranslated(0., 0., -height);
	gluQuadricOrientation(obj, GLU_INSIDE);
	gluDisk(obj, 0, radius, slices, 1);
 
	gluQuadricOrientation(obj, GLU_OUTSIDE);
    gluCylinder(obj, radius, radius, height*2, slices, 1);
 
	glTranslated(0., 0., height*2);
	gluDisk(obj, 0., radius, slices, 1);
 
	glTranslated(0., 0., -height);
 
	gluDeleteQuadric(obj);
}

void DrawGround() {			
  glColor3f(  0.9, 0.9, 0.9);	// Bottom of Grid
 /*
  glBegin(GL_POLYGON);
	glVertex3f(-2.0,-0.51, 2.0);
	glVertex3f( 2.0,-0.51, 2.0);
	glVertex3f( 2.0,-0.51,-2.0);
	glVertex3f(-2.0,-0.51,-2.0);
  glEnd();
*/	
  glColor3ub(50, 50, 50);		// Grid
  glBegin(GL_LINES);
    for (float x = -2.0; x <= 2.2; x += 0.2) {
      glVertex3f(x,-0.5,-2.0);
      glVertex3f(x,-0.5, 2.0);
    }

    for (float z = -2.0; z <= 2.2; z += 0.2) {
      glVertex3f(-2.0,-0.5, z);
      glVertex3f( 2.0,-0.5, z);
    }
  glEnd();
}

void XYZ() {
	const GLfloat red[]		= { 1.0, 0.0, 0.0, 1.0 };
	const GLfloat green[]	= { 0.0, 1.0, 0.0, 1.0 };
	const GLfloat blue[]	= { 0.0, 0.0, 1.0, 1.0 };
	const GLfloat white[]	= { 1.0, 1.0, 1.0, 1.0 };
	const GLfloat black[]	= { 0.0, 0.0, 0.0, 1.0 };
	const GLfloat teapot[]	= { 0.5, 0.6, 1.0, 1.0 };
	const GLfloat polished[]= { 100.0 };
	const GLfloat dull[] = { 0.0 };

	GLfloat LightPosition[ ] = {1.0, 1.0, 1.0, 1.0};							
	GLfloat Shx = 0.5, Shy = 0.5, Shz = 0.5;

	GLfloat ShearX_matrix[4][4] = { // Shearing along X according to Y
		 { 1.0, Shx, 0.0, 0.0 },
		 { 0.0,  1.0, 0.0, 0.0 },
		 { 0.0,  0.0, 1.0, 0.0 },
		 { 0.0,  0.0, 0.0, 1.0 }
	};

	GLfloat ShearY_matrix[4][4] = {  // Shearing along Y according to X 
		 {  1.0, 0.0, 0.0, 0.0 },
		 { Shy, 1.0, 0.0, 0.0 },
		 {  0.0, 0.0, 1.0, 0.0 },
		 {  0.0, 0.0, 0.0, 1.0 }
	};

	GLfloat ShearZ_matrix[4][4] = {  // Shearing along Z according to Y 
		 {  1.0, 0.0, 0.0, 0.0 },
		 { 0.0, 1.0, 0.0, 0.0 },
		 {  0.0, Shz, 1.0, 0.0 },
		 {  0.0, 0.0, 0.0, 1.0 }
	};

	GLfloat ShearXY_matrix[4][4] = {  // Shearing along XY according to Z 
		 {  1.0, 0.0, Shx, 0.0 },
		 {  0.0, 0.0, Shy, 0.0 },
		 {  0.0, 0.0,  1.0, 0.0 },
		 {  0.0, 0.0,  0.0, 1.0 }
	};

	GLfloat ShearXZ_matrix[4][4] = {  // Shearing along XZ according to Y 
		 {  1.0, Shx, 0.0, 0.0 },
		 {  0.0,  1.0,  0.0, 0.0 },
		 {  0.0, Shz, 1.0, 0.0 },
		 {  0.0,  0.0,  0.0, 1.0 }
	};

	GLfloat ShearYZ_matrix[4][4] = {  // Shearing along YZ according to X 
		 {  1.0, 0.0, 0.0, 0.0 },
		 { Shy, 1.0, 0.0, 0.0 },
		 { Shz, 0.0, 1.0, 0.0 },
		 {  0.0, 0.0,  0.0, 1.0 }
	};

	glLightfv(GL_LIGHT0, GL_POSITION, LightPosition);

	// XYZ Coordinate - Cone
	glPushMatrix();					// X�� ȭ��ǥ
		glTranslatef(2.5, 0.0, 0.0);
		glColor3f(1.0, 0.0, 0.0);
		glRotatef(90.0, 0.0, 1.0, 0.0);
		glutSolidCone(0.1, 0.3, 10, 5); 
	glPopMatrix();

	glPushMatrix();					// Y�� ȭ��ǥ
		glTranslatef(0.0, 2.5, 0.0);
		glColor3f(0.0, 1.0, 0.0);
		glRotatef(270.0, 1.0, 0.0, 0.0);
		glutSolidCone(0.1, 0.3, 10, 5);
	glPopMatrix();

	glPushMatrix();					// Z�� ȭ��ǥ
		glTranslatef(0.0, 0.0, 2.8);
		glColor3f(0.0, 0.0, 1.0);
		glutSolidCone(0.1, 0.3, 10, 5);
	glPopMatrix();
	
	// XYZ Coordinate - Line
	glPushMatrix();					// Z�� ����     
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, blue);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(0.0, 0.0, 1.0);
		glTranslatef(0.0, 0.0, 1.35);
		oglCylinder(2.7, 0.03);
	glPopMatrix();

	glPushMatrix();					// X�� ����
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, red);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(1.0, 0.0, 0.0);
		glTranslatef(1.25, 0.0, 0.0);
		glRotatef(90.0, 0.0, 1.0, 0.0);
		oglCylinder(2.5, 0.03);
	glPopMatrix();

	glPushMatrix();					// Y�� ����
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, green);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(0.0, 1.0, 0.0);
		glTranslatef(0.0, 1.25, 0.0);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		oglCylinder(2.5, 0.03);
	glPopMatrix();

	glPushMatrix();					// Cube
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, teapot);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glMultMatrixf((float*)ShearX_matrix);
		glutSolidCube(1.5);
	glPopMatrix();

	glDisable(GL_LIGHTING);
}

void MyReshape( int w, int h ) {
    glViewport( 0, 0, (GLsizei)w, (GLsizei)h );
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity( );

	glOrtho(-3.0, 3.0, -3.0, 3.0, -5.0, 5.0);
    gluLookAt(eyex, eyey, eyez, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

	glMatrixMode( GL_MODELVIEW );
    glLoadIdentity( );
}

void MyDisplay(void) {
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	XYZ();
	DrawGround();

	glFlush ();
}

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_ALPHA | GLUT_DEPTH);
   glutInitWindowSize (800, 550); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("Shear Transformation");
   InitLight();
   glClearColor (1.0, 1.0, 1.0, 1.0);
   glutDisplayFunc(MyDisplay); 
   glutReshapeFunc(MyReshape);

   glutMainLoop();
   return 0;   
}
