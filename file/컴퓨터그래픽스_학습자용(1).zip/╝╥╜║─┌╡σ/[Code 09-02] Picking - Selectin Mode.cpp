#include <Windows.h>
#include <stdio.h>
#include <glut.h>
#include <glu.h>

static POINT	ptLastMousePosit;
static POINT	ptCurrentMousePosit;
static bool		bMousing;

float g_fDistance = -5.0f;
float g_fSpinX    = 0.0f;
float g_fSpinY    = 0.0f;

void DrawGLScene()	{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

    glTranslatef( 0.0f, 0.0f, g_fDistance );
    glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

	glInitNames();

	glEnable(GL_LIGHTING);

	glPushName(100);
	glPushMatrix();
		glColor3f(1.0f, 0.0f, 0.0f);
		glutWireTeapot(0.3);
	glPopMatrix();
	glPopName();

	glPushName(101);
	glPushMatrix();
		glColor3f(0.0f, 1.0f, 0.0f);
		glTranslatef(-1.0f, -1.0f, 0.0f);
		glutSolidSphere(0.3, 30, 30);
	glPopMatrix();
	glPopName();

	glPushName(102);	
	glPushMatrix();	
		glColor3f(0.0f, 0.0f, 1.0f);
		glTranslatef(1.0f, 1.0f, 0.0f);
		glutSolidSphere(0.3, 30, 30);
	glPopMatrix();
	glPopName();

	glPushName(103);
	glPushMatrix();
		glColor3f(1.0f, 1.0f, 0.0f);
		glTranslatef(-1.0f, 1.0f, 0.0f);
		glutSolidSphere(0.3, 30, 30);
	glPopMatrix();
	glPopName();

	glPushName(104);
	glPushMatrix();
		glColor3f(0.0f, 1.0f, 1.0f);
		glTranslatef(1.0f, -1.0f, 0.0f);
		glutSolidSphere(0.3, 30, 30);
	glPopMatrix();
	glPopName();

	glDisable(GL_LIGHTING);

	glPushName(105);
	glColor3f(0.7f, 0.7f, 1.0f);
	glBegin(GL_LINES);
		glVertex2f(-1.0f, -1.0f);
		glVertex2f(1.0f, -1.0f);

		glVertex2f(1.0f, -1.0f);
		glVertex2f(1.0f, 1.0f);

		glVertex2f(1.0f, 1.0f);
		glVertex2f(-1.0f, 1.0f);
	
		glVertex2f(-1.0f, 1.0f);
		glVertex2f(-1.0f, -1.0f);

		glVertex2f(0.0f, 1.5f);
		glVertex2f(0.0f, -1.5f);

		glVertex2f(1.5f, 0.0f);
		glVertex2f(-1.5f, 0.0f);

		glVertex2f(1.5f, 1.5f);
		glVertex2f(-1.5f, -1.5f);
	glEnd();
	glPopName();

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_LINES);
		glVertex2f(-1.5f, 1.5f);
		glVertex2f(1.5f, -1.5f);
	glEnd();

	glutSwapBuffers();
}

void ProcessSelect(GLuint index[64]) {
	switch(index[3]) {
		case 100: MessageBox(NULL, "Red Wire Teapot", "Selection", MB_OK); break;
		case 101: MessageBox(NULL, "Green Solid Sphere", "Selection", MB_OK); break;
		case 102: MessageBox(NULL, "Blue Solid Sphere", "Selection", MB_OK); break;
		case 103: MessageBox(NULL, "Yellow Solid Sphere", "Selection", MB_OK); break;
		case 104: MessageBox(NULL, "Cyan Solid Sphere", "Selection", MB_OK); break;
		case 105: MessageBox(NULL, "Line", "Selection", MB_OK); break;

		default: MessageBox(NULL, "What?", "Selection", MB_OK); break;
	}
}

void SelectObjects(GLint x, GLint y) {
	GLuint selectBuff[64];
	GLint hits, viewport[4];

	glSelectBuffer(64, selectBuff);
	glGetIntegerv(GL_VIEWPORT, viewport);
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
		glRenderMode(GL_SELECT);
		glLoadIdentity();
		gluPickMatrix(x, viewport[3]-y, 2, 2, viewport);

		gluPerspective(45.0f,1.0, 0.1f, 100.0f);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		DrawGLScene();

		hits = glRenderMode(GL_RENDER);
		if(hits>0) ProcessSelect(selectBuff);
		glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void MyMouse(int button, int state, int x, int y) {
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN) {
            ptLastMousePosit.x = ptCurrentMousePosit.x = x;
            ptLastMousePosit.y = ptCurrentMousePosit.y = y;
			SelectObjects(ptCurrentMousePosit.x, ptCurrentMousePosit.y);
            bMousing = true;
		 } else 
			bMousing = false;
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         break;
      default:
         break;
   }

   glutPostRedisplay();
}

void MyMotion(int x, int y) {
	ptCurrentMousePosit.x = x;
    ptCurrentMousePosit.y = y;

    if( bMousing )
    {
		g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
        g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
    }

    ptLastMousePosit.x = ptCurrentMousePosit.x;
    ptLastMousePosit.y = ptCurrentMousePosit.y;

    glutPostRedisplay();
}

int InitGL() {
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHT0);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	return TRUE;
}

void MyReshape( int w, int h ) {
    glViewport( 0, 0, (GLsizei)w, (GLsizei)h );
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity( );

    gluPerspective (45, (GLfloat)w / (GLfloat)h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (640, 480); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("Selection Mode - Picking");
   InitGL();
   glutDisplayFunc( DrawGLScene ); 
   glutReshapeFunc( MyReshape );
   glutMouseFunc(MyMouse);
   glutMotionFunc(MyMotion);

   glutMainLoop();
   return 0;   
}
