#include <time.h>
#include <glut.h>

unsigned char PALETTE[16][3] = {
     { 1.0, 1.0, 1.0 },     // White
     { 0.0, 1.0, 1.0 },     // Cyan
     { 1.0, 0.0, 1.0 },     // Purple
     { 0.0, 0.0, 1.0 },     // Blue
     { 0.7, 0.7, 0.7 },     // Light Gray
     { 0.5, 0.5, 0.5 },     // Dark Gray
     { 0.0, 0.5, 0.5 },     // Dark Teal
     { 0.5, 0.0, 0.5 },     // Dark Purple
     { 0.0, 0.0, 0.5 },     // Dark Blue
     { 1.0, 1.0, 0.0 },     // Yellow
     { 0.0, 1.0, 0.0 },     // Green
     { 0.5, 0.5, 0.0 },     // Dark Yellow
     { 0.0, 0.5, 0.0 },     // Dark Green
     { 1.0, 0.0, 0.0 },     // Red
     { 0.5, 0.0, 0.0 },     // Dark Red
     { 0.0, 0.0, 0.0 }      // Black
};

GLint Index = 0; 
GLfloat Delta = 0.0, Red = 0.0, Green = 0.0, Blue = 0.0;

void MyDisplay( ) {
     Red   = PALETTE[Index][0];
     Green = PALETTE[Index][1];
     Blue  = PALETTE[Index][2];

     glColor3f(Red, Green, Blue);

     glBegin(GL_LINES);
         glVertex3f(-1.0 + Delta,  1.0 - Delta, 0.0 - Delta);
	     glVertex3f( 1.0 - Delta,  1.0 - Delta, 0.0 - Delta);

	     glVertex3f(-1.0 + Delta, -1.0 + Delta, 0.0 - Delta);
		 glVertex3f( 1.0 - Delta, -1.0 + Delta, 0.0 - Delta);

         glVertex3f(-1.0 + Delta,  1.0 - Delta, 0.0 - Delta);
	     glVertex3f(-1.0 + Delta, -1.0 + Delta, 0.0 - Delta);

	     glVertex3f( 1.0 - Delta,  1.0 - Delta, 0.0 - Delta);
		 glVertex3f( 1.0 - Delta, -1.0 + Delta, 0.0 - Delta);
     glEnd();

     glutSwapBuffers();
}

void MyTimer(int Value) { 
    if (Delta < 2.0f)
		Delta = Delta + 0.01;
    else {
        Delta = 0.0;
        if (++Index >= 15)
			Index = 0;

        glClear(GL_COLOR_BUFFER_BIT);	
    }

    glutPostRedisplay();
    glutTimerFunc(10, MyTimer, 1); 
}

void MyInit() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glOrtho(-1.0, 1.0, -1.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("Timer Animation using Timer Callback");
    MyInit();
    glutTimerFunc(10, MyTimer, 1); 
    glutDisplayFunc(MyDisplay);

    glutMainLoop();
    return 0;
}