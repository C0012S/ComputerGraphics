#include<stdlib.h>
#include<stdio.h>
#include <iostream>
using namespace std;
#include <io.h>
#include <glut.h>
#include <glaux.h>

class vertex{
public:
	float x,y,z;
};

//MapCoord - for storing texture mapping coords
class mapcoord{
public:
	float u,v;
};

//The three ints for the polygon
//represent the no.s(or rank) of it's 3 vertices
class polygon{
public:
	int a,b,c;
};

//Our object consists of a name,the vertex and polygons quantity,
//3000 vertices,3000 polygons, and 3000 mapping coords
//The value 3000 should be increased in order to load high-res models.
class object{
public:
	char name[20];
	int numVerts,numPolys;
	vertex v[3000];
	polygon p[3000];
	mapcoord m[3000];
};

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

float g_fDistance = -400.0f;
float g_fSpinX    = 0.0f;
float g_fSpinY    = 0.0f;

bool g_bRenderInWireFrame = false;
unsigned int g_textureID = 1;

object g_Obj3ds;  //our object

//-----------------------------------------------------------------------------
// Name: Load3dsObject (object *, char *)
// Desc: Loads a 3ds object given a filename
//-----------------------------------------------------------------------------
void Load3dsObject (object *obj, char *filename) {
	FILE *file;			//Our file pointer
	char temp;			//Temporary char for reading name of object
	short chunkID;		//Stores ID of current chunk.
	int chunkLength;
	short useless;
	
	//Open our file for reading(r) and in binary mode(b)- "rb"
	file=fopen (filename, "rb");

	//While current position is lesser than the total length
	while (ftell(file) < filelength (fileno (file))) {
		fread (&chunkID, 2, 1, file); 
		fread (&chunkLength, 4, 1,file); 

		switch (chunkID) {
			case 0x4d4d:		//Skip these chunks
				break;    
			case 0x3d3d:
				break;
			
			case 0x4000:		//Chunk containing name
				for(int i=0;i<20;i++) {
					fread (&temp, 1, 1, file);
                    obj->name[i]=temp;
					if(temp == '\0')break;
                }
				break;

			case 0x3f80:		//Skip again
				break;
			case 0x4100:
				break;
	
			case 0x4110:		//Chunk with num of vertices
								//followed by their coordinates
				fread (&obj->numVerts, sizeof (unsigned short), 1, file);
				for (int i=0; i<obj->numVerts; i++) {
					fread (&obj->v[i].x, sizeof(float), 1, file);
 				
                    fread (&obj->v[i].y, sizeof(float), 1, file);
 					
					fread (&obj->v[i].z, sizeof(float), 1, file);
 				
				}
				break;

			case 0x4120:		 //Chunk with numPolys and the indices
				fread (&obj->numPolys, sizeof (unsigned short), 1, file);
                for (int i=0; i<obj->numPolys; i++) {
					fread (&obj->p[i].a, sizeof (unsigned short), 1, file);				
					fread (&obj->p[i].b, sizeof (unsigned short), 1, file);				
					fread (&obj->p[i].c, sizeof (unsigned short), 1, file);					
					fread (&useless, sizeof (unsigned short), 1, file);					
				}
				break;

		
			case 0x4140:		//Chunk with texture coords
				fread (&useless, sizeof (unsigned short), 1, file);
				for (int i=0; i<obj->numVerts; i++) {
					fread (&obj->m[i].u, sizeof (float), 1, file);				
                    fread (&obj->m[i].v, sizeof (float), 1, file);
				}
                break;

			default:
				 fseek(file,chunkLength-6, SEEK_CUR);
        } 
	}
	fclose (file);		
}

void MyInit( void ) {
	glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
	glEnable( GL_TEXTURE_2D );
	glEnable( GL_DEPTH_TEST );

	//Loading 3ds object here//
	Load3dsObject(&g_Obj3ds,"Data/spaceship.3ds");
	AUX_RGBImageRec *pTextureImage = auxDIBImageLoad( "Data/spaceshiptexture.bmp" );

	if( pTextureImage != NULL ) {
		glGenTextures( 1, &g_textureID );
		glBindTexture( GL_TEXTURE_2D, g_textureID );
		glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER, GL_LINEAR );
		glTexParameteri( GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER, GL_LINEAR );
		glTexImage2D( GL_TEXTURE_2D, 0, 3, pTextureImage->sizeX, pTextureImage->sizeY, 0,
			GL_RGB, GL_UNSIGNED_BYTE, pTextureImage->data );
	}

	if( pTextureImage ) {
		if( pTextureImage->data )
			free( pTextureImage->data );
		free( pTextureImage );
	}
}

//-----------------------------------------------------------------------------
// Name: DrawObject(object *)
// Desc: Draws the given 3ds object
//-----------------------------------------------------------------------------
void DrawObject(object *obj) {
	glBegin(GL_TRIANGLES);				//3ds models consist of triangles
    for (int i=0;i<obj->numPolys;i++) {	//For each triangle
 		glTexCoord2f( obj->m[ obj->p[i].a ].u,	//1st vertex:Mapping coordinates
                      obj->m[ obj->p[i].a ].v);
        glVertex3f( obj->v[ obj->p[i].a ].x,	//1st vertex: x
                    obj->v[ obj->p[i].a ].y,	//1st vertex: y
                    obj->v[ obj->p[i].a ].z);	//1st vertex: z

		glTexCoord2f( obj->m[ obj->p[i].b ].u,	//2nd vertex:Mapping coordinates
                      obj->m[ obj->p[i].b ].v);
        glVertex3f( obj->v[ obj->p[i].b ].x,	//2nd vertex: x
                    obj->v[ obj->p[i].b ].y,	//2nd vertex: y
                    obj->v[ obj->p[i].b ].z);	//2nd vertex: z

		glTexCoord2f( obj->m[ obj->p[i].c ].u,	//3rd vertex:Mapping coordinates
                      obj->m[ obj->p[i].c ].v);
        glVertex3f( obj->v[ obj->p[i].c ].x,	//3rd vertex: x
                    obj->v[ obj->p[i].c ].y,	//3rd vertex: y
                    obj->v[ obj->p[i].c ].z);	//3rd vertex: z
	}
    glEnd();

}

void MyDisplay(void) {
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

    glTranslatef( 0.0f, 0.0f, g_fDistance );
    glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

	if(g_bRenderInWireFrame)
		glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
	else
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
		
	DrawObject(&g_Obj3ds);

	glutPostRedisplay();
	glutSwapBuffers();
}

void MyReshape(int w,int h) {    
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

    gluPerspective (45, (GLfloat)w / (GLfloat)h, 0.1, 1000.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void MySpecial(int key, int x, int y) {
	if(key == GLUT_KEY_PAGE_UP) {
		g_fDistance -= 1.1f;
	} else if(key == GLUT_KEY_PAGE_DOWN) {
		g_fDistance += 1.1f;
	} else if(key == GLUT_KEY_HOME) {
		g_bRenderInWireFrame=!g_bRenderInWireFrame;
	} 

	glutPostRedisplay();
}

void MyMouse(int button, int state, int x, int y) {
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN) {
            ptLastMousePosit.x = ptCurrentMousePosit.x = x;
            ptLastMousePosit.y = ptCurrentMousePosit.y = y;
            bMousing = true;
		 } else 
			bMousing = false;
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         break;
      default:
         break;
   }

   glutPostRedisplay();
}

void MyMotion(int x, int y) {
	ptCurrentMousePosit.x = x;
    ptCurrentMousePosit.y = y;

    if( bMousing )
    {
		g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
        g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
    }

    ptLastMousePosit.x = ptCurrentMousePosit.x;
    ptLastMousePosit.y = ptCurrentMousePosit.y;

    glutPostRedisplay();
}

int main(int argc,char **argv) {
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH);
	glutInitWindowSize(800,600);
	glutInitWindowPosition(0,0);
	glutCreateWindow("OpenGL Modeling - 3DS Loader");

	MyInit();
	glutReshapeFunc(MyReshape);
    glutDisplayFunc(MyDisplay);
	glutMouseFunc(MyMouse);
	glutMotionFunc(MyMotion);
	glutSpecialFunc(MySpecial);

	glutMainLoop();
	return 0;
}
