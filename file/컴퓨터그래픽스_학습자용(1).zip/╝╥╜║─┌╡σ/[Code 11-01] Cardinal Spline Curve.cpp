#include <vector>
using std::vector;
#include <glut.h>

const int startwinsize = 640;
const double vertsize = 10.;		// Size of control pts (pixels)
const double curvewid = 4.;			// Width of drawn curve (pixels)
const double polywid = 2.;			// Width of control polygon (pixels)
const int numcurvesegments = 100;	// Number of line segs per curve segment
const double tensionchg = 0.01;		// Amt to chg tension on single keypress
double tension;

vector<vector<GLdouble> > verts;	// Vector of 2-D control pts
bool currentlymoving;				// Are we dragging a control pt?
int selectedvert;					// Index of dragged pt; valid if currentlymoving
vector<GLdouble> savevert;			// Start coords of dragged control pt
int savemx, savemy;					// Start mouse pos when dragging (pixels)

// Draws cardinal spline, given vector of control points, number of line segments to draw for each spline segment, and tension
// First and last segments used 2nd deriv = 0 constraint on first & last control pt.
void drawCardinalSpline (
    const vector<vector<GLdouble> > & v,	// ctrl pts
    int segs,								// num segments
    double s) {								// tension

    int n = verts.size();					// Number of control points

    if (n <= 2) {
        if (n == 1) {
            glBegin(GL_POINTS);
                glVertex2dv(&v[0][0]);
            glEnd();
        } else if (n == 2) {
            glBegin(GL_LINES);
                glVertex2dv(&v[0][0]);
                glVertex2dv(&v[1][0]);
            glEnd();
        }
        return;
    }

    // n >= 3    
    double xa, xb, xc, xd;  // Coefficients for x-coord polynomial
    double ya, yb, yc, yd;  // Coefficients for y-coord polynomial

    glBegin(GL_LINE_STRIP);
        // Draw 1st segment
        xa = (1.0-s)/2*verts[0][0] - 1.0/2*verts[1][0] +  s/2*verts[2][0];
        xb = 0.0;
		xc = (s-3.0)/2*verts[0][0] + 3.0/2*verts[1][0] + -s/2*verts[2][0];
        xd = verts[0][0];
        ya = (1.0-s)/2*verts[0][1] - 1.0/2*verts[1][1] +  s/2*verts[2][1];
        yb = 0.0;
        yc =  (s-3.)/2*verts[0][1] + 3.0/2*verts[1][1] + -s/2*verts[2][1];
        yd = verts[0][1];

        for (int k = 1; k <= segs; ++k) {
            double t = double(k)/segs;  // parameter
            double x = xa*t*t*t + xb*t*t + xc*t + xd;
            double y = ya*t*t*t + yb*t*t + yc*t + yd;
            glVertex2d(x, y);
        }

        // Draw intermediate segments
        glVertex2dv(&verts[1][0]);
        for (int j = 0; j < n-3; ++j) {
            xa =   -s*verts[j][0] + (2.-s)*verts[j+1][0] +    (s-2.)*verts[j+2][0] + s*verts[j+3][0];
			xb = 2.*s*verts[j][0] + (s-3.)*verts[j+1][0] + (3.-2.*s)*verts[j+2][0] - s*verts[j+3][0];
            xc =   -s*verts[j][0] +      s*verts[j+2][0]; 
            xd =      verts[j+1][0]; 
            ya =   -s*verts[j][1] + (2.-s)*verts[j+1][1] +    (s-2.)*verts[j+2][1] + s*verts[j+3][1];
            yb = 2.*s*verts[j][1] + (s-3.)*verts[j+1][1] + (3.-2.*s)*verts[j+2][1] - s*verts[j+3][1];
            yc =   -s*verts[j][1] +      s*verts[j+2][1];
			yd =      verts[j+1][1];

            for (int k = 1; k <= segs; ++k) {
                double t = double(k)/segs;
                double x = xa*t*t*t + xb*t*t + xc*t + xd;
                double y = ya*t*t*t + yb*t*t + yc*t + yd;
                glVertex2d(x, y);
            }
        }

        // Draw last segment
        xa =   -s/2*verts[n-3][0] + 1./2*verts[n-2][0] +    (s-1.)/2*verts[n-1][0];
        xb = 3.*s/2*verts[n-3][0] - 3./2*verts[n-2][0] + (3.-3.*s)/2*verts[n-1][0];
        xc =     -s*verts[n-3][0] +    s*verts[n-1][0]; 
		xd =        verts[n-2][0];
        ya =   -s/2*verts[n-3][1] + 1./2*verts[n-2][1] +    (s-1.)/2*verts[n-1][1];
        yb = 3.*s/2*verts[n-3][1] - 3./2*verts[n-2][1] + (3.-3.*s)/2*verts[n-1][1];
        yc =     -s*verts[n-3][1] +    s*verts[n-1][1]; 
		yd =        verts[n-2][1];

        for (int k = 1; k <= segs; ++k) {
            double t = double(k)/segs;
            double x = xa*t*t*t + xb*t*t + xc*t + xd;
            double y = ya*t*t*t + yb*t*t + yc*t + yd;
            glVertex2d(x, y);
        }

    glEnd();
}

void MyDisplay() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw control points ("verts")
	glPointSize(vertsize);
    glBegin(GL_POINTS);
		for (int i=0; i<verts.size(); ++i) {
			if (i==selectedvert)
				glColor3d(1., 0., 0.);
            else
                glColor3d(0., 0., 0.);

            glVertex2dv(&verts[i][0]);
		}
    glEnd();

    // Draw curve
    glColor3d(0., 0., 1.);
    glPointSize(curvewid);
    glLineWidth(curvewid);
    drawCardinalSpline(verts, numcurvesegments, tension);

    glutSwapBuffers();
}

void MySpecial(int key, int x, int y) {
	if(key == GLUT_KEY_PAGE_UP) {
		tension += tensionchg;
	} else if(key == GLUT_KEY_PAGE_DOWN) {
		tension -= tensionchg;
	}

	glutPostRedisplay();
}

void MyMouse(int button, int state, int x, int y) {
	switch (button) {
		case GLUT_LEFT_BUTTON:
			if (state == GLUT_DOWN) {
				int mousex = x;
				int mousey = startwinsize-y;

				// Check if clicked on a vert
				int i;
				for (i = 0; i < verts.size(); ++i) {
					int slop = (vertsize/2)+2;
					if (mousex >= verts[i][0]-slop
						&& mousex <= verts[i][0]+slop
						&& mousey >= verts[i][1]-slop
						&& mousey <= verts[i][1]+slop) break;
				}

				// If did not click on a vert, make a new one
				if (i == verts.size()) {
					verts.push_back(vector<GLdouble>(2));
					verts[i][0] = mousex;
					verts[i][1] = mousey;
				}

				// Select vert & get ready for moving
				selectedvert = i;
				savemx = mousex; savemy = mousey;
				savevert = verts[i];
				currentlymoving = true;
			} else 
				currentlymoving = false;
			break;
		case GLUT_MIDDLE_BUTTON:
			if (state == GLUT_DOWN) {
				tension = 0.5;
			}
			break;
		case GLUT_RIGHT_BUTTON:
			if (state == GLUT_DOWN) {
				if (verts.size() > 0) {
					verts.pop_back();
					selectedvert = -1;
					currentlymoving = false;
				}					
			}
			break;
		default:
			break;
	}

    glutPostRedisplay();
}

void MyMotion(int x, int y) {
    if (!currentlymoving) return;

    int mousex = x;
    int mousey = startwinsize-y;

    verts[selectedvert][0] = savevert[0]+mousex-savemx;
    verts[selectedvert][1] = savevert[1]+mousey-savemy;

    glutPostRedisplay();
}

void MyReshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(0.,(double)w, (double)startwinsize-h,(double)startwinsize);
    glMatrixMode(GL_MODELVIEW);
}

void MyInit() {
    currentlymoving = false;
    selectedvert = -1;
    tension = 0.5;
    glClearColor(1.0, 1.0, 1.0, 0.0);
}

int main(int argc, char ** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(640, 480);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("Cardinal Spline Curve");
    MyInit();
    glutDisplayFunc(MyDisplay);
    glutReshapeFunc(MyReshape);
    glutMouseFunc(MyMouse);
    glutMotionFunc(MyMotion);
	glutSpecialFunc(MySpecial);

    glutMainLoop();
    return 0;
}

