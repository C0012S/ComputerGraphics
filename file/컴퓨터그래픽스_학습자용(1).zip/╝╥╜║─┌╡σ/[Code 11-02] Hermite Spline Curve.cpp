#include <stdlib.h>
#include <glut.h>

float Geometry[4][3] = { 
	{ 10,10,0 },	//	Point1
	{-10,5,-2 },	//	Point2
	{ 5,-5,0  },	//	Tangent1
	{ 5,10,0  }		//	Tangent2
};
unsigned int LOD=20;

void OnReshape(int w, int h) {
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluPerspective(45,(float)w/h,0.1,100);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void OnDraw() {
	glClear(GL_DEPTH_BUFFER_BIT|GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(	1,10,30,0,5,0,0,1,0);

	glColor3f(0.5,0.5,1);
	glEnable(GL_DEPTH_TEST);

	glBegin(GL_LINE_STRIP);
		// use the parametric time value 0 to 1
		for(int i=0;i!=LOD;++i) {
			float t = (float)i/(LOD-1);
			// calculate blending functions
			float b0 =  2*t*t*t - 3*t*t + 1;
			float b1 = -2*t*t*t + 3*t*t;
			float b2 = t*t*t - 2*t*t + t;
			float b3 = t*t*t - t*t;

			// calculate the x,y and z of the curve point
			float x = b0*Geometry[0][0] + 
					  b1*Geometry[1][0] + 
					  b2*Geometry[2][0] + 
					  b3*Geometry[3][0] ;

			float y = b0*Geometry[0][1] + 
					  b1*Geometry[1][1] + 
					  b2*Geometry[2][1] + 
					  b3*Geometry[3][1] ;

			float z = b0*Geometry[0][2] + 
					  b1*Geometry[1][2] + 
					  b2*Geometry[2][2] + 
					  b3*Geometry[3][2] ;

			// specify the point
			glVertex3f( x,y,z );
		}
	glEnd();


	glColor3f(0,1,0.5);
	glPointSize(3);
	glBegin(GL_POINTS);
		glVertex3fv( Geometry[0] );
		glVertex3fv( Geometry[1] );
	glEnd();

	glColor3f(0.5,1,0.5);
	glPushMatrix();
		glTranslatef(Geometry[0][0],Geometry[0][1],Geometry[0][2]);
		glBegin(GL_LINES);
			glVertex3f( 0,0,0 );
			glVertex3fv( Geometry[2] );
		glEnd();
	glPopMatrix();

	glPushMatrix();
		glTranslatef(Geometry[1][0],Geometry[1][1],Geometry[1][2]);
		glBegin(GL_LINES);
			glVertex3f( 0,0,0 );
			glVertex3fv( Geometry[3] );
		glEnd();
	glPopMatrix();

	// currently we've been drawing to the back buffer, we need
	// to swap the back buffer with the front one to make the image visible
	glutSwapBuffers();
}

int main(int argc,char** argv) {
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DEPTH|GLUT_RGBA|GLUT_DOUBLE);
	glutInitWindowSize(640,480);
	glutCreateWindow("Hermite Spline");
	glutDisplayFunc(OnDraw);
	glutReshapeFunc(OnReshape);

	glutMainLoop();
	return 0;
}
