#include <stdio.h>
#include <math.h>
#include <glut.h>
 
int windowWidth=800, windowHeight=600;
float cpx[20], cpy[20], cpz[20];	// Maximum Values of Control Points
int numPts = 0,  indx = -1;

int MyPick(float x, float y) {
    for(int i = 0; i < numPts; i ++)
	   if(fabs(x - cpx[i]) < 0.2  &&  fabs(y - cpy[i]) < 0.2)
		   return i;
}

void MyDisplay() {
    float xcr, ycr, zcr;			// Points on the Catmull-Rom spline
    float dx, dy, dz;				// Tangent components

	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPointSize(6.0); 
    glColor3f(1.0, 0.0, 1.0);
    glBegin(GL_POINTS);
		for(int i = 0; i < numPts; i++)
			   glVertex3f(cpx[i], cpy[i], cpz[i]);
    glEnd();

	if(numPts > 3) {
	   glColor3f(1.0, 0.0, 0.0);
	   glBegin(GL_LINES);						// Draw Tangents
		   for(int i = 1; i < numPts-1; i++) {
			   dx = 0.2*(cpx[i+1]-cpx[i-1]);
			   dy = 0.2*(cpy[i+1]-cpy[i-1]);
			   dz = 0.2*(cpz[i+1]-cpz[i-1]);
			   glVertex3f(cpx[i]-dx, cpy[i]-dy, cpz[i]-dz);
			   glVertex3f(cpx[i]+dx, cpy[i]+dy, cpz[i]+dz);
			}
        glEnd();

	    glColor3f(1.0, 1.0, 0.0);
	    glBegin(GL_LINE_STRIP);
			for(int i = 1; i < numPts-2; i++) {
				for(int k = 0;  k < 50; k++) {		// 50 points
				   float t = k*0.02;				// Interpolation parameter
				   xcr = cpx[i] + 0.5*t*(-cpx[i-1]+cpx[i+1]) 
					   + t*t*(cpx[i-1] - 2.5*cpx[i] + 2*cpx[i+1] - 0.5*cpx[i+2])
					   + t*t*t*(-0.5*cpx[i-1] + 1.5*cpx[i] - 1.5*cpx[i+1] + 0.5*cpx[i+2]);
				   ycr = cpy[i] + 0.5*t*(-cpy[i-1]+cpy[i+1]) 
					   + t*t*(cpy[i-1] - 2.5*cpy[i] + 2*cpy[i+1] - 0.5*cpy[i+2])
					   + t*t*t*(-0.5*cpy[i-1] + 1.5*cpy[i] - 1.5*cpy[i+1] + 0.5*cpy[i+2]);
				   zcr = cpz[i] + 0.5*t*(-cpz[i-1]+cpz[i+1]) 
					   + t*t*(cpz[i-1] - 2.5*cpz[i] + 2*cpz[i+1] - 0.5*cpz[i+2])
					   + t*t*t*(-0.5*cpz[i-1] + 1.5*cpz[i] - 1.5*cpz[i+1] + 0.5*cpz[i+2]);

 				   glVertex3f(xcr, ycr, zcr);
			   }
			}
		glEnd();
	}
	glFlush(); 
}

void MyMotion(int x, int y) {
	float xW = (float)(x*8.0)/windowWidth;
	float yW = (float)(windowHeight-y)*6.0/windowHeight;

	if(indx > -1) {
        cpx[indx] = xW; 
        cpy[indx] = yW;
    }

	glutPostRedisplay();
}

void MyMouse(int button, int state, int x, int y) {
	float xW = (float)(x*8.0)/windowWidth;
	float yW = (float)(windowHeight-y)*6.0/windowHeight;

	if(button==GLUT_LEFT_BUTTON && state ==GLUT_DOWN) {
		   cpx[numPts] = xW;
		   cpy[numPts] = yW;
		   numPts++;
	} else if(button==GLUT_RIGHT_BUTTON && state ==GLUT_DOWN)
			indx = MyPick(xW, yW);

	glutPostRedisplay();
}

void MyReshape(int w, int h) {
	windowWidth = w;
	windowHeight = h;
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

	glOrtho(0.0, 8.0, 0.0, 6.0, 0.0, 6.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void main(int argc, char **argv) { 
	glutInit(&argc, argv);            
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);  
	glutInitWindowSize(windowWidth, windowHeight);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Catmull-Rom Spline Curve");

	glutDisplayFunc(MyDisplay);
    glutReshapeFunc(MyReshape);
	glutMouseFunc(MyMouse);
	glutMotionFunc(MyMotion);

	glutMainLoop(); 
}