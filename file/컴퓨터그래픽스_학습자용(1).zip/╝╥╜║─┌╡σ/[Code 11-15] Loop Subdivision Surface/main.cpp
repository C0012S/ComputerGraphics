#include <windows.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <gl/glut.h>
#include "loop.h"

float g_fDistance = -3.0f;
float g_fSpinX    =  0.0f;
float g_fSpinY    =  0.0f;

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

WingedEdge* we = NULL; /* our new model (formerly pmodel) */

int wire = 0;
char *filename;

void DrawModel() {
	if (!we) {
		we = readOBJ("data/drum.obj"); 
		if (!we) exit(0);
		unitize(we);
		facetNormals(we);
	}
    
	if (wire)	wireObject(we);
	else		flatObject(we);
}

void MyReshape(int width, int height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

	gluPerspective(45.0, 1.0, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    gluLookAt(0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

void MyDisplay() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	glClearColor(0.8,0.8,0.8,0.8);
    glTranslatef( 0.0f, 0.0f, g_fDistance );
	glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
	glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

	glRotatef(-45.0, 0.0, 1.0, 0.0);
	glRotatef(30.0, 1.0, 0.0, 0.0);
	DrawModel();

	glutSwapBuffers();
}

void MyMouse(int button, int state, int x, int y) {
    switch (button) {
         case GLUT_LEFT_BUTTON:
               if (state == GLUT_DOWN) {
                   ptLastMousePosit.x = ptCurrentMousePosit.x = x;
                   ptLastMousePosit.y = ptCurrentMousePosit.y = y;
                   bMousing = true;
               } else
                    bMousing = false;
               break;
          case GLUT_MIDDLE_BUTTON:
          case GLUT_RIGHT_BUTTON:
               if (state == GLUT_DOWN) {
					if( faceCount(we) >= 65536) break;
					else {
						subdivide(we); 
						refine(we);
						unitize(we);
						facetNormals(we);
						printf("%d Doritos!\n", faceCount(we));
						break;
					}
			   }
			   break;
          default:
               break;
     }

     glutPostRedisplay();
}

void MyMotion(int x, int y) {
     ptCurrentMousePosit.x = x;
     ptCurrentMousePosit.y = y;

     if( bMousing ) {
          g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
          g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
     }

     ptLastMousePosit.x = ptCurrentMousePosit.x;
     ptLastMousePosit.y = ptCurrentMousePosit.y;

     glutPostRedisplay();
}

void MyKeyboard(unsigned char key, int x, int y) {
	char* name = 0;
	Vertex* vertex;
	long lines = 0;
	
	switch (key) {
		case 'W':
		case 'w':
			wire = !wire;
			break;
		case 'T':
		case 't':
			name = "data/top.obj";
			break;
		case 'D':
		case 'd':
			name = "data/drum.obj";
			break;
		case 'R':
		case 'r':
			name = "data/rtet.obj";
			break;
		case 'B':
		case 'b':
			name = "data/ball.obj";
			break;
		case 'P':
		case 'p':
			name = "data/prism.obj";
			break;
	}
    
	if (name) {
		if (we) free(we);
		we = readOBJ(name); 
		if (!we) exit(0);
		unitize(we);
		facetNormals(we);
	}

    glutPostRedisplay(); 
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutInitWindowPosition(50, 50);
	glutInitWindowSize(640, 480);
	glutCreateWindow("Loop Subdivision Surface");

	glutReshapeFunc(MyReshape);
	glutDisplayFunc(MyDisplay);
	glutKeyboardFunc(MyKeyboard);
	glutMouseFunc(MyMouse);            
	glutMotionFunc(MyMotion);            

	glutMainLoop();    
	return 0;
}