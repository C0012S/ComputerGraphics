////////////////////////////////////////////////////////////////////////////////         
// bicubicSplineSurface.cpp
// 
// This program draws the bicubic B-spline approximation of a 15x10 array of 
// movable control points over a fixed standard knot vector in either direction.
//
// Interaction:
// Press space, backspace, tab and enter keys to select a control point.
// Press the right/left arrow keys to move the control point up/down the x-axis.
// Press the up/down arrow keys to move the control point up/down the y-axis.
// Press the page up/down keys to move the control point up/down the z-axis.
// Press the x, X, y, Y, z, Z keys to rotate the viewpoint.
// Press delete to reset control points.

#include <Windows.h>
#include <iostream>
#include <glut.h>
using namespace std;

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

float g_fDistance = -15.0f;
float g_fSpinX    =  0.0f;
float g_fSpinY    =  0.0f;

static float controlPoints[10][10][3];						// Control points.
static int rowCount = 0, columnCount = 0;					// Indexes of selected control point.
static GLUnurbsObj *nurbsObject;							// Pointer to NURBS object.

// Standard knot vector along the u-parameter.
static float uknots[14] =  {0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 7.0, 7.0, 7.0};

// Standard knot vector along the v-parameter.
static float vknots[14] = {0.0, 0.0, 0.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 7.0, 7.0, 7.0};

void resetControlPoints() {
	for (int i = 0; i < 10; i++)  
		for (int j = 0; j < 10; j++) {
			controlPoints[i][j][0] = 4.5 - j;
			controlPoints[i][j][1] = 0.0;
			controlPoints[i][j][2] = 4.5 - i;
		}

	rowCount = columnCount = 5;
}

void setup() {
	glClearColor(1.0, 1.0, 1.0, 0.0);

	// Create NURBS object.
	nurbsObject = gluNewNurbsRenderer();
	gluNurbsProperty(nurbsObject, GLU_SAMPLING_METHOD, GLU_PATH_LENGTH);
	gluNurbsProperty(nurbsObject, GLU_SAMPLING_TOLERANCE, 100.0);
	gluNurbsProperty(nurbsObject, GLU_DISPLAY_MODE, GLU_OUTLINE_POLYGON);

	resetControlPoints();
}
/*
void oglCylinder (double height, double radius) {
	height /= 2.;
 
	int slices = 15;
	GLUquadricObj *obj = gluNewQuadric();
 
	glTranslated(0., 0., -height);
	gluQuadricOrientation(obj, GLU_INSIDE);
	gluDisk(obj, 0, radius, slices, 1);
 
	gluQuadricOrientation(obj, GLU_OUTSIDE);
    gluCylinder(obj, radius, radius, height*2, slices, 1);
 
	glTranslated(0., 0., height*2);
	gluDisk(obj, 0., radius, slices, 1);
 
	glTranslated(0., 0., -height);
 
	gluDeleteQuadric(obj);
}

void XYZ() {
	const GLfloat red[]		= { 1.0, 0.0, 0.0, 1.0 };
	const GLfloat green[]	= { 0.0, 1.0, 0.0, 1.0 };
	const GLfloat blue[]	= { 0.0, 0.0, 1.0, 1.0 };
	const GLfloat white[]	= { 1.0, 1.0, 1.0, 1.0 };
	const GLfloat black[]	= { 0.0, 0.0, 0.0, 1.0 };
	const GLfloat polished[]= { 100.0 };

	// XYZ Coordinate - Cone
	glPushMatrix();					// X�� ȭ��ǥ
		glTranslatef(2.5, 0.0, 0.0);
		glColor3f(1.0, 0.0, 0.0);
		glRotatef(90.0, 0.0, 1.0, 0.0);
		glutSolidCone(0.2, 0.6, 10, 5); 
	glPopMatrix();

	glPushMatrix();					// Y�� ȭ��ǥ
		glTranslatef(0.0, 2.5, 0.0);
		glColor3f(0.0, 1.0, 0.0);
		glRotatef(270.0, 1.0, 0.0, 0.0);
		glutSolidCone(0.2, 0.6, 10, 5);
	glPopMatrix();

	glPushMatrix();					// Z�� ȭ��ǥ
		glTranslatef(0.0, 0.0, 2.8);
		glColor3f(0.0, 0.0, 1.0);
		glutSolidCone(0.2, 0.6, 10, 5);
	glPopMatrix();


	// XYZ Coordinate - Line
	glPushMatrix();					// Z�� ����     
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, blue);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(0.0, 0.0, 1.0);
		glTranslatef(0.0, 0.0, 1.35);
		oglCylinder(2.7, 0.06);
	glPopMatrix();

	glPushMatrix();					// X�� ����
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, red);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(1.0, 0.0, 0.0);
		glTranslatef(1.25, 0.0, 0.0);
		glRotatef(90.0, 0.0, 1.0, 0.0);
		oglCylinder(2.5, 0.06);
	glPopMatrix();

	glPushMatrix();					// Y�� ����
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, green);
		glMaterialfv(GL_FRONT, GL_SPECULAR, white);
		glMaterialfv(GL_FRONT, GL_SHININESS, polished);

		glColor3f(0.0, 1.0, 0.0);
		glTranslatef(0.0, 1.25, 0.0);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		oglCylinder(2.5, 0.06);
	glPopMatrix();
}
*/
void MyDisplay() {
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    glTranslatef( 0.0f, 0.0f, g_fDistance );
    glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );
	glRotatef(45.0, 1.0, 0.0, 0.0);
/*
	glTranslatef(-4.5, 0, -4.5);
	XYZ();
	glTranslatef(4.5, 0, 4.5);
*/
	// Draw the spline surface.
	glColor3f(0.5, 0.0, 0.0);
	gluBeginSurface(nurbsObject);
	gluNurbsSurface(nurbsObject, 14, uknots, 14, vknots, 30, 3, controlPoints[0][0], 4, 4, GL_MAP2_VERTEX_3);
	gluEndSurface(nurbsObject);

	// Draw blue control points.
	glPointSize(5.0);
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_POINTS);
		for (int i = 0; i < 10; i++)
			for (int j = 0; j < 10; j++)
				glVertex3fv(controlPoints[i][j]);
	glEnd();

	// Draw red selected control point.
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_POINTS);
		glVertex3fv(controlPoints[rowCount][columnCount]);
	glEnd();

	glutSwapBuffers();
}

void MyMouse(int button, int state, int x, int y) {
     switch (button) {
          case GLUT_LEFT_BUTTON:
               if (state == GLUT_DOWN) {
                    ptLastMousePosit.x = ptCurrentMousePosit.x = x;
                    ptLastMousePosit.y = ptCurrentMousePosit.y = y;
                    bMousing = true;
               } else 
                    bMousing = false;
                    break;
          case GLUT_MIDDLE_BUTTON:
          case GLUT_RIGHT_BUTTON:
               break;
          default:
               break;
     }

    glutPostRedisplay();
}

void MyMotion(int x, int y) {
     ptCurrentMousePosit.x = x;
     ptCurrentMousePosit.y = y;

     if( bMousing )
     {
          g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
          g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
     }

     ptLastMousePosit.x = ptCurrentMousePosit.x;
     ptLastMousePosit.y = ptCurrentMousePosit.y;

     glutPostRedisplay();
}

void MyKeyboard(unsigned char key, int x, int y) {
	switch(key) {
      case 9:     // Tab
		 {
		    if (rowCount < 10) rowCount++;
		    else rowCount = 0;
		 }
		 break;
      case 13:   // Enter
		 if (rowCount > 0) rowCount--;
		 else rowCount = 10;
         break;
      case ' ':  // Space bar
		 {
		    if (columnCount < 9) columnCount++;
		    else columnCount = 0;
		 }
         break;
      case 8:   // Back Space bar
		 if (columnCount > 0) columnCount--;
		 else columnCount = 9;
         break;
      case 127:	// Del
         resetControlPoints();
         break;
      default:
         break;
   }

   glutPostRedisplay();
}

void MySpecial(int key, int x, int y) {
	if (key == GLUT_KEY_LEFT)		controlPoints[rowCount][columnCount][0] -= 0.1;
	if (key == GLUT_KEY_RIGHT)		controlPoints[rowCount][columnCount][0] += 0.1;
	if (key == GLUT_KEY_DOWN)		controlPoints[rowCount][columnCount][1] -= 0.1;
	if (key == GLUT_KEY_UP)			controlPoints[rowCount][columnCount][1] += 0.1;
	if (key == GLUT_KEY_PAGE_DOWN)	controlPoints[rowCount][columnCount][2] += 0.1;
	if (key == GLUT_KEY_PAGE_UP)	controlPoints[rowCount][columnCount][2] -= 0.1;

	glutPostRedisplay();
}

void MyReshape(int w, int h) {	
	glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(45.0, (GLfloat)w/(GLfloat)h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int main(int argc, char **argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); 
	glutInitWindowSize(640, 480);
	glutInitWindowPosition(100, 100); 
	glutCreateWindow("Bicubic B-Spline Surface");
	setup(); 
	glutDisplayFunc(MyDisplay); 
	glutReshapeFunc(MyReshape);  
	glutKeyboardFunc(MyKeyboard);
	glutSpecialFunc(MySpecial);
	glutMouseFunc(MyMouse);
    glutMotionFunc(MyMotion);
	glutMainLoop(); 

	return 0;  
}
