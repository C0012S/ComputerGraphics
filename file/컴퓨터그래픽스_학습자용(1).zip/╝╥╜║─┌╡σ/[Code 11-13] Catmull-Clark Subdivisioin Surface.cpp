#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <assert.h>
using namespace std;
#include <glut.h>
#include <glext.h>

float g_fDistance = -4.5f;
float g_fSpinX    = 0.0f;
float g_fSpinY    = 0.0f;

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

// structure to store a 3d point, note that for this assignment, the vector also stores a level which is used to denote which level of subdivion has been computed on that point (to not displace a point twice), given the data structure we are using
typedef struct Vector3 {
     float x;
     float y;
     float z;

     int level;
     Vector3(float in_x, float in_y, float in_z) : x(in_x), y(in_y), z(in_z), level(0) {}
     Vector3() : x(0), y(0), z(0), level(0) {}
     Vector3(const Vector3& in_v) : x(in_v.x), y(in_v.y), z(in_v.z), level(0) {}
     Vector3(float in) : x(in), y(in), z(in), level(0) {}
     inline Vector3& operator = (const Vector3& v2) {
          x = v2.x; y=v2.y; z=v2.z; level =v2.level; return *this;
     }
     inline void set(float in_x, float in_y, float in_z) { x = in_x; y = in_y; z = in_z; level = 0;}
} Vector3;

char strPop[256];

void renderBitmapCharacher(float x, float y, float z, void *font,char *string) {
     char *c;
     glRasterPos3f(x, y, z);
     for (c=string; *c != '\0'; c++) {
          glutBitmapCharacter(font, *c);
     }
}

// Catmull-Clark Subdivision surface�� ���� ��(Point)���� ���� (Level 0 �� 3)
Vector3 CCSurf[17][17][4];

int L, R, T, B;
int DrawLevel = 0;
// ��(Point)�� ���� ����
// 3--------2
// |         |
// |         |
// 0--------1

void InitCCSurf() {
     int level=0;
     L=B=0;
     R=T=16;

     CCSurf[L][B][level] = Vector3(-1, -0.3,  1);
     CCSurf[R][B][level] = Vector3( 1, -0.3,  1);
     CCSurf[R][T][level] = Vector3( 1, -0.3, -1);
     CCSurf[L][T][level] = Vector3(-1, -0.3, -1);

     // ���õ� Geometry�� Edge �߽���(Midpoint)���� ���� �߽ɺ� ����
     CCSurf[(R-L)/2][(T-B)/2][level] = Vector3(0, 1, 0);
     CCSurf[(R-L)/2][B][level] = Vector3(0, 0, 1);
     CCSurf[R][(T-B)/2][level] = Vector3(1, 0, 0);
     CCSurf[(R-L)/2][T][level] = Vector3(0, 0, -1);
     CCSurf[L][(T-B)/2][level] = Vector3(-1, 0, 0);
}

// �־��� Level�� Patch�� �־��� �κ��� �׸��� ���� Routine
void DrawPatch(int Lev, int Lft, int Rght, int Bot, int Top) {
     Vector3 v1, v2,norm;
     int skip = (Rght-Lft)/powf(2,(Lev+1));

     for (int i=Lft; i <Rght; i += skip) {
          for (int j=Bot; j<Top; j+=skip) {
               glBegin(GL_LINE_LOOP);
                    glColor3f(0.0, 0.0, 1.0);
                    glVertex3f(CCSurf[i][j][Lev].x, CCSurf[i][j][Lev].y, CCSurf[i][j][Lev].z);
                    glVertex3f(CCSurf[i+skip][j][Lev].x, CCSurf[i+skip][j][Lev].y, CCSurf[i+skip][j][Lev].z);
                       glVertex3f(CCSurf[i+skip][j+skip][Lev].x,CCSurf[i+skip][j+skip][Lev].y, CCSurf[i+skip][j+skip][Lev].z);
                       glVertex3f(CCSurf[i][j+skip][Lev].x, CCSurf[i][j+skip][Lev].y, CCSurf[i][j+skip][Lev].z);
               glEnd();
          }
     }
}

// Face Point�� �����ϰ� Edge �߽���(Midpoint)�� ���
void SubdivFace(int L1, int R1, int B1, int T1, int Lev) {
     // ���� Level ��ġ�� ����Ͽ� Edge���� ���� ���
     float div =2;

     // Bottom edge
     if (CCSurf[L1+(R1-L1)/2][B1][Lev].level < Lev) {
          CCSurf[L1+(R1-L1)/2][B1][Lev] = Vector3 (
               CCSurf[L1][B1][Lev-1].x+CCSurf[R1][B1][Lev-1].x,
               CCSurf[L1][B1][Lev-1].y+CCSurf[R1][B1][Lev-1].y,
               CCSurf[L1][B1][Lev-1].z+CCSurf[R1][B1][Lev-1].z);

          CCSurf[L1+(R1-L1)/2][B1][Lev].x /= div;
          CCSurf[L1+(R1-L1)/2][B1][Lev].y /= div;
          CCSurf[L1+(R1-L1)/2][B1][Lev].z /= div;
          CCSurf[L1+(R1-L1)/2][B1][Lev].level = Lev;
     }

     // Top edge
     if (CCSurf[L1+(R1-L1)/2][T1][Lev].level < Lev) {
          CCSurf[L1+(R1-L1)/2][T1][Lev] = Vector3 (
               CCSurf[L1][T1][Lev-1].x+CCSurf[R1][T1][Lev-1].x,
               CCSurf[L1][T1][Lev-1].y+CCSurf[R1][T1][Lev-1].y,
               CCSurf[L1][T1][Lev-1].z+CCSurf[R1][T1][Lev-1].z);

          CCSurf[L1+(R1-L1)/2][T1][Lev].x /= div;
          CCSurf[L1+(R1-L1)/2][T1][Lev].y /= div;
          CCSurf[L1+(R1-L1)/2][T1][Lev].z /= div;
          CCSurf[L1+(R1-L1)/2][T1][Lev].level = Lev;
     }

     // Left edge
     if (CCSurf[L1][B1+(T1-B1)/2][Lev].level < Lev) {
          CCSurf[L1][B1+(T1-B1)/2][Lev] = Vector3 (
               CCSurf[L1][B1][Lev-1].x+CCSurf[L1][T1][Lev-1].x,
               CCSurf[L1][B1][Lev-1].y+CCSurf[L1][T1][Lev-1].y,
               CCSurf[L1][B1][Lev-1].z+CCSurf[L1][T1][Lev-1].z);

          CCSurf[L1][B1+(T1-B1)/2][Lev].x /= div;
          CCSurf[L1][B1+(T1-B1)/2][Lev].y /=div;
          CCSurf[L1][B1+(T1-B1)/2][Lev].z /= div;
          CCSurf[L1][B1+(T1-B1)/2][Lev].level = Lev;
     }

     // Right edge
     if (CCSurf[R1][B1+(T1-B1)/2][Lev].level < Lev) {
          CCSurf[R1][B1+(T1-B1)/2][Lev] = Vector3 (
               (CCSurf[R1][B1][Lev-1].x+CCSurf[R1][T1][Lev-1].x),
               (CCSurf[R1][B1][Lev-1].y+CCSurf[R1][T1][Lev-1].y),
               (CCSurf[R1][B1][Lev-1].z+CCSurf[R1][T1][Lev-1].z));

          CCSurf[R1][B1+(T1-B1)/2][Lev].x /= div;
          CCSurf[R1][B1+(T1-B1)/2][Lev].y /= div;
          CCSurf[R1][B1+(T1-B1)/2][Lev].z /= div;
          CCSurf[R1][B1+(T1-B1)/2][Lev].level = Lev;
     }

     // Face Point�� �߽ɺη� ����
     CCSurf[L1+(R1-L1)/2][B1+(T1-B1)/2][Lev] = Vector3 (
          (CCSurf[L1][B1+(T1-B1)/2][Lev].x+CCSurf[R1][B1+(T1-B1)/2][Lev].x)/2.0,
          (CCSurf[L1][B1+(T1-B1)/2][Lev].y+CCSurf[R1][B1+(T1-B1)/2][Lev].y)/2.0,
          (CCSurf[L1][B1+(T1-B1)/2][Lev].z+CCSurf[R1][B1+(T1-B1)/2][Lev].z)/2.0);

     // ������ ���� �ϱ� ���Ͽ� ���� Level�� �������� ����
     CCSurf[R1][B1][Lev] = CCSurf[R1][B1][Lev-1];
     CCSurf[R1][T1][Lev] = CCSurf[R1][T1][Lev-1];
     CCSurf[L1][B1][Lev] = CCSurf[L1][B1][Lev-1];
     CCSurf[L1][T1][Lev] = CCSurf[L1][T1][Lev-1];
}

// �־��� Level���� Patch�� �־��� ��ġ�� Subdivide�ϱ� ���� Routine
void SubDivPatch(int Lev, int Lft, int Rght, int Bot, int Top) {
     Vector3 v1, v2,norm;
     int skip = (Rght-Lft)/powf(2,Lev);

     // Edge�� �����ϴ� ��(Face)���� Subdivide
     for (int i=Lft; i <Rght; i +=skip) {
          for (int j=Bot; j<Top; j+=skip) {
               SubdivFace(i, i+skip, j, j+skip, Lev);
          }
     }
}

void MyDisplay() {
     glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
     glMatrixMode( GL_MODELVIEW );
     glLoadIdentity();

     glTranslatef( 0.0f, 0.0f, g_fDistance );
     glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
     glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

     renderBitmapCharacher(-1.3,1.3,0,(void *)GLUT_BITMAP_HELVETICA_12,strPop);

     glRotatef(45.0, 1.0, 0.0, 0.0);
     DrawPatch(DrawLevel, L, R, B, T);

     glutSwapBuffers();
     glFlush();
}

void MyMouse(int button, int state, int x, int y) {
     switch (button) {
          case GLUT_LEFT_BUTTON:
               if (state == GLUT_DOWN) {
                    ptLastMousePosit.x = ptCurrentMousePosit.x = x;
                    ptLastMousePosit.y = ptCurrentMousePosit.y = y;
                    bMousing = true;
                } else
                    bMousing = false;
                break;
          case GLUT_MIDDLE_BUTTON:
          case GLUT_RIGHT_BUTTON:
               if (state == GLUT_DOWN) {
                    DrawLevel++;
                    if (DrawLevel < 4) {
                         SubDivPatch(DrawLevel,L,R, B, T);
                         sprintf(strPop, "Catmull-Clark Subdivision Level %d", DrawLevel);
                    } else {
                         DrawLevel--;
                         sprintf(strPop, "Max Level Reached!");
                    }
               }
               break;
          default:
               break;
     }

     glutPostRedisplay();
}

void MyMotion(int x, int y) {
     ptCurrentMousePosit.x = x;
     ptCurrentMousePosit.y = y;

     if( bMousing ) {
          g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
          g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
     }

     ptLastMousePosit.x = ptCurrentMousePosit.x;
     ptLastMousePosit.y = ptCurrentMousePosit.y;

     glutPostRedisplay();
}

void MyReshape(int w, int h) {
     glViewport(0,0,w,h);
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();

     gluPerspective(40.0, (GLfloat)w/(GLfloat)h, 1.0, 100.0);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();
}

void InitGL() {
     glClearColor(1.0, 1.0, 1.0, 1.0);
     glEnable(GL_DEPTH_TEST);
     InitCCSurf();
     sprintf(strPop, "Catmull-Clark Subdivision Level %d", DrawLevel);
}

int main( int argc, char** argv ) {
     glutInit(&argc, argv);
     glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
     glutInitWindowSize(640, 480); 
     glutInitWindowPosition(100, 100);
     glutCreateWindow("Catmull-Clark Subdivision Surface");
	 InitGL();
     glutDisplayFunc(MyDisplay);
     glutReshapeFunc(MyReshape);
     glutMouseFunc(MyMouse);
     glutMotionFunc(MyMotion);

     glutMainLoop();
     return 0;
}