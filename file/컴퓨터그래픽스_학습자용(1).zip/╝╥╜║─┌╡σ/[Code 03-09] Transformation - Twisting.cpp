#include <Windows.h>
#include <math.h>
#include <glut.h>

float g_fDistance = -70.0f;
float g_fSpinX    = 0.0f;
float g_fSpinY    = 0.0f;

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

float		vertexes[4][3];
float		normal[3];

void ReduceToUnit(float vector[3]) {							// Reduces A Normal Vector (3 Coordinates)
																// To A Unit Normal Vector With A Length Of One.
	float length;												// Holds Unit Length

	// Calculates The Length Of The Vector
	length = (float)sqrt((vector[0]*vector[0]) + (vector[1]*vector[1]) + (vector[2]*vector[2]));

	if(length == 0.0f)											// Prevents Divide By 0 Error By Providing
		length = 1.0f;											// An Acceptable Value For Vectors To Close To 0.

	vector[0] /= length;										// Dividing Each Element By
	vector[1] /= length;										// The Length Results In A
	vector[2] /= length;										// Unit Normal Vector.
}

void calcNormal(float v[3][3], float out[3]) {					// Calculates Normal For A Quad Using 3 Points
	float v1[3],v2[3];											// Vector 1 (x,y,z) & Vector 2 (x,y,z)
	static const int x = 0;										// Define X Coord
	static const int y = 1;										// Define Y Coord
	static const int z = 2;										// Define Z Coord

	// Finds The Vector Between 2 Points By Subtracting
	// The x,y,z Coordinates From One Point To Another.

	// Calculate The Vector From Point 1 To Point 0
	v1[x] = v[0][x] - v[1][x];									// Vector 1.x=Vertex[0].x-Vertex[1].x
	v1[y] = v[0][y] - v[1][y];									// Vector 1.y=Vertex[0].y-Vertex[1].y
	v1[z] = v[0][z] - v[1][z];									// Vector 1.z=Vertex[0].y-Vertex[1].z
	
	// Calculate The Vector From Point 2 To Point 1
	v2[x] = v[1][x] - v[2][x];									// Vector 2.x=Vertex[0].x-Vertex[1].x
	v2[y] = v[1][y] - v[2][y];									// Vector 2.y=Vertex[0].y-Vertex[1].y
	v2[z] = v[1][z] - v[2][z];									// Vector 2.z=Vertex[0].z-Vertex[1].z

	// Compute The Cross Product To Give Us A Surface Normal
	out[x] = v1[y]*v2[z] - v1[z]*v2[y];							// Cross Product For Y - Z
	out[y] = v1[z]*v2[x] - v1[x]*v2[z];							// Cross Product For X - Z
	out[z] = v1[x]*v2[y] - v1[y]*v2[x];							// Cross Product For X - Y

	ReduceToUnit(out);											// Normalize The Vectors
}

void ProcessHelix()	{											// Draws A Helix
	GLfloat x, y, z;											// Helix x,y,z Coordinate
	GLfloat phi,theta, v, u;									// Angles
	GLfloat r;													// Radius Of Twist
	int twists = 3;												// 3 Twists

	GLfloat glfMaterialColor[]={0.4f,0.2f,0.8f,1.0f};			// Set The Material Color
	GLfloat specular[]={1.0f,1.0f,1.0f,1.0f};					// Sets Up Specular Lighting

    glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,glfMaterialColor);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,specular);
	
	r = 3.5f;													// Radius

	glBegin(GL_QUADS);											// Begin Drawing Quads
	for(phi=0; phi <= 360; phi+=5.0) {							// 360 Degrees In Steps Of 5
		for(theta=0; theta<=360*twists; theta+=5.0) {			// 360 Degrees * Number Of Twists In Steps Of 5
			v=(phi/180.0f*3.142f);								// Calculate Angle Of First Point	(  0 )
			u=(theta/180.0f*3.142f);							// Calculate Angle Of First Point	(  0 )

			x=float(cos(u)*(2.0f+cos(v) ))*r;					// Calculate x Position (1st Point)
			y=float(sin(u)*(2.0f+cos(v) ))*r;					// Calculate y Position (1st Point)
			z=float((( u-(2.0f*3.142f)) + sin(v) ) * r);		// Calculate z Position (1st Point)

			vertexes[0][0]=x;									// Set x Value Of First Vertex
			vertexes[0][1]=y;									// Set y Value Of First Vertex
			vertexes[0][2]=z;									// Set z Value Of First Vertex

			v=(phi/180.0f*3.142f);								// Calculate Angle Of Second Point	(  0 )
			u=((theta+20)/180.0f*3.142f);						// Calculate Angle Of Second Point	( 20 )

			x=float(cos(u)*(2.0f+cos(v) ))*r;					// Calculate x Position (2nd Point)
			y=float(sin(u)*(2.0f+cos(v) ))*r;					// Calculate y Position (2nd Point)
			z=float((( u-(2.0f*3.142f)) + sin(v) ) * r);		// Calculate z Position (2nd Point)

			vertexes[1][0]=x;									// Set x Value Of Second Vertex
			vertexes[1][1]=y;									// Set y Value Of Second Vertex
			vertexes[1][2]=z;									// Set z Value Of Second Vertex

			v=((phi+20)/180.0f*3.142f);							// Calculate Angle Of Third Point	( 20 )
			u=((theta+20)/180.0f*3.142f);						// Calculate Angle Of Third Point	( 20 )

			x=float(cos(u)*(2.0f+cos(v) ))*r;					// Calculate x Position (3rd Point)
			y=float(sin(u)*(2.0f+cos(v) ))*r;					// Calculate y Position (3rd Point)
			z=float((( u-(2.0f*3.142f)) + sin(v) ) * r);		// Calculate z Position (3rd Point)

			vertexes[2][0]=x;									// Set x Value Of Third Vertex
			vertexes[2][1]=y;									// Set y Value Of Third Vertex
			vertexes[2][2]=z;									// Set z Value Of Third Vertex

			v=((phi+20)/180.0f*3.142f);							// Calculate Angle Of Fourth Point	( 20 )
			u=((theta)/180.0f*3.142f);							// Calculate Angle Of Fourth Point	(  0 )

			x=float(cos(u)*(2.0f+cos(v) ))*r;					// Calculate x Position (4th Point)
			y=float(sin(u)*(2.0f+cos(v) ))*r;					// Calculate y Position (4th Point)
			z=float((( u-(2.0f*3.142f)) + sin(v) ) * r);		// Calculate z Position (4th Point)

			vertexes[3][0]=x;									// Set x Value Of Fourth Vertex
			vertexes[3][1]=y;									// Set y Value Of Fourth Vertex
			vertexes[3][2]=z;									// Set z Value Of Fourth Vertex

			calcNormal(vertexes,normal);						// Calculate The Quad Normal

			glNormal3f(normal[0],normal[1],normal[2]);			// Set The Normal

			// Render The Quad
			glVertex3f(vertexes[0][0],vertexes[0][1],vertexes[0][2]);
			glVertex3f(vertexes[1][0],vertexes[1][1],vertexes[1][2]);
			glVertex3f(vertexes[2][0],vertexes[2][1],vertexes[2][2]);
			glVertex3f(vertexes[3][0],vertexes[3][1],vertexes[3][2]);
		}
	}
	glEnd();
}

void InitGL() {
	GLfloat global_ambient[4]={0.2f, 0.2f,  0.2f, 1.0f};
	GLfloat light0pos[4]=     {0.0f, 5.0f, 10.0f, 1.0f};
	GLfloat light0ambient[4]= {0.2f, 0.2f,  0.2f, 1.0f};
	GLfloat light0diffuse[4]= {0.3f, 0.3f,  0.3f, 1.0f};
	GLfloat light0specular[4]={0.8f, 0.8f,  0.8f, 1.0f};
	GLfloat lmodel_ambient[]= {0.2f,0.2f,0.2f,1.0f};

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT,lmodel_ambient);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, global_ambient);
	glLightfv(GL_LIGHT0, GL_POSITION, light0pos);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light0ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light0diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light0specular);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glShadeModel(GL_SMOOTH);
	glMateriali(GL_FRONT, GL_SHININESS, 128);
	glClearColor(0.0f, 0.0f, 0.0f, 0.5);
}

void MyReshape(int w, int h) {	
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(40.0, (GLfloat)w/(GLfloat)h, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void MyDisplay() {
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    glTranslatef( 0.0f, 0.0f, g_fDistance );
    glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

	ProcessHelix();

    glutSwapBuffers();
}

void MyMouse(int button, int state, int x, int y) {
    switch (button) {
         case GLUT_LEFT_BUTTON:
               if (state == GLUT_DOWN) {
                   ptLastMousePosit.x = ptCurrentMousePosit.x = x;
                   ptLastMousePosit.y = ptCurrentMousePosit.y = y;
                   bMousing = true;
               } else 
                    bMousing = false;
               break;
          case GLUT_MIDDLE_BUTTON:
          case GLUT_RIGHT_BUTTON:
               break;
          default:
               break;
     }

     glutPostRedisplay();
}

void MyMotion(int x, int y) {
     ptCurrentMousePosit.x = x;
     ptCurrentMousePosit.y = y;

     if( bMousing ) {
          g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
          g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
     }

     ptLastMousePosit.x = ptCurrentMousePosit.x;
     ptLastMousePosit.y = ptCurrentMousePosit.y;

     glutPostRedisplay();
}

void main(int argc, char ** argv) {
	glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(800, 600);
    glutCreateWindow("Transformation - Twist");
    InitGL();
    glutDisplayFunc(MyDisplay);
    glutReshapeFunc(MyReshape);
    glutMouseFunc(MyMouse);
    glutMotionFunc(MyMotion);

    glutMainLoop( );
}