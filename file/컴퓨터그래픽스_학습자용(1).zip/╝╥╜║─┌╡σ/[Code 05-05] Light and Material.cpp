#include <glut.h>

void MyInit(void) {
   GLfloat ambient[] = { 0.0, 0.0, 0.0, 1.0 };
   GLfloat diffuse[] = { 1.0, 1.0, 1.0, 1.0 }; 
   GLfloat specular[] = { 1.0, 1.0, 1.0, 1.0 }; 
   GLfloat position[] = { 0.0, 3.0, 2.0, 0.0 }; 
   GLfloat lmodel_ambient[] = { 0.4, 0.4, 0.4, 1.0 };
   GLfloat local_view[] = { 0.0 }; 

   glClearColor(0.0, 0.0, 0.0, 0.0);
   glEnable(GL_DEPTH_TEST);
   glShadeModel(GL_SMOOTH);

   glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
   glLightfv(GL_LIGHT0, GL_POSITION, position);
   glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
   glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);

   glEnable(GL_LIGHTING); 
   glEnable(GL_LIGHT0);
}

void MyDisplay(void) {
   GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
   GLfloat mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 }; 
   GLfloat mat_ambient_color[] = { 0.8, 0.8, 0.2, 1.0 };
   GLfloat mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 }; 
   GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 }; 
   GLfloat no_shininess[] = { 0.0 }; 
   GLfloat low_shininess[] = { 5.0 }; 
   GLfloat high_shininess[] = { 100.0 }; 
   GLfloat mat_emission[] = {0.3, 0.2, 0.2, 0.0}; 

   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 

   //  Draw sphere in first row, first column
   //  Diffuse reflection only; no ambient or specular
   glPushMatrix();
      glTranslatef (-3.75, 3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

   //  Draw sphere in first row, second column
   //  Diffuse and specular reflection; low shininess; no ambient
   glPushMatrix();
      glTranslatef (-1.25, 3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in first row, third column
  //  Diffuse and specular reflection; high shininess; no ambient
   glPushMatrix();
      glTranslatef (1.25, 3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

   //  Draw sphere in first row, fourth column
   //  Diffuse reflection; emission; no ambient or specular reflection
   glPushMatrix();
      glTranslatef (3.75, 3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

   //  Draw sphere in second row, first column
   //  ambient and diffuse reflection; no specular
   glPushMatrix();
      glTranslatef (-3.75, 0.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in second row, second column
  //  Ambient, diffuse and specular reflection; low shininess
   glPushMatrix();
      glTranslatef (-1.25, 0.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in second row, third column
  //  Ambient, diffuse and specular reflection; high shininess
   glPushMatrix();
      glTranslatef (1.25, 0.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in second row, fourth column
  //  Ambient and diffuse reflection; emission; no specular
   glPushMatrix();
      glTranslatef (3.75, 0.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in third row, first column
  //  Colored ambient and diffuse reflection; no specular
   glPushMatrix();
      glTranslatef (-3.75, -3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient_color);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in third row, second column
  //  Colored ambient, diffuse and specular reflection; low shininess
   glPushMatrix();
      glTranslatef (-1.25, -3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient_color);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in third row, third column
  //  Colored ambient, diffuse and specular reflection; high shininess
   glPushMatrix();
      glTranslatef (1.25, -3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient_color);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
      glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

  //  Draw sphere in third row, fourth column
  //  Colored ambient and diffuse reflection; emission; no specular
   glPushMatrix();
      glTranslatef (3.75, -3.0, 0.0);
      glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient_color);
      glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
      glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
      glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
      glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
      glutSolidSphere(1.0, 16, 16);
   glPopMatrix();

   glFlush();
}

void MyReshape(int w, int h) {
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();

   glOrtho (-6.0, 6.0, -3.0*((GLfloat)h*2)/(GLfloat)w, 3.0*((GLfloat)h*2)/(GLfloat)w, -10.0, 10.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (600, 450);
   glutCreateWindow("Light and Material");
   MyInit();
   glutReshapeFunc(MyReshape);
   glutDisplayFunc(MyDisplay);

   glutMainLoop();
   return 0; 
}