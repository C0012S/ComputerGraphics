#include <stdlib.h>
#include <glut.h>

#define NUMSTEPS 0.01
#define tension  0.50

GLfloat P[4][4][3] = {
     {{-4.5, -4.5, 12.0}, {-1.5, -4.5,  6.0}, {1.5, -4.5, -3.0}, {4.5, -4.5,  6.0}},
     {{-4.5, -1.5,  3.0}, {-1.5, -1.5,  9.0}, {1.5, -1.5,  0.0}, {4.5, -1.5, -3.0}},
     {{-4.5,  1.5, 12.0}, {-1.5,  1.5,  0.0}, {1.5,  1.5,  9.0}, {4.5,  1.5, 12.0}},
     {{-4.5,  4.5, -6.0}, {-1.5,  4.5, -6.0}, {1.5,  4.5,  0.0}, {4.5,  4.5, -3.0}}
};
 
GLfloat SM[] = {1.0f, 1.0f, 0.0f, 0.0f, 
              0.0f, 0.0f, 1.0f, 1.0f,
              0.0f, 0.33333333333333f, 0.0f, 0.0f,
              0.0f, 0.0f, -0.33333333333333f, 0.0f};

GLfloat MT[] = {1.0f, 0.0f, 0.0f, 0.0f,
               1.0f, 0.0f, 0.33333333333333f, 0.0f,
               0.0f, 1.0f, 0.0f, -0.33333333333333f,
               0.0f, 1.0f, 0.0f, 0.0f};
 
GLfloat StartPt_s(int ii, int jj) {
     return P[jj][1][ii];
}

GLfloat EndPt_s(int ii, int jj) {
     return P[jj][2][ii]; 
}
 
GLfloat StartTan_s(int ii, int jj) {
     return( (1-tension)*(P[jj][2][ii] - P[jj][0][ii])/2 );
}

GLfloat EndTan_s(int ii, int jj) {
     return( (1-tension)*(P[jj][3][ii] - P[jj][1][ii])/2 );
}

GLfloat StartPt_t(int ii, int jj) {
     return P[1][jj][ii]; 
}

GLfloat EndPt_t(int ii, int jj) {
     return P[2][jj][ii]; 
}

GLfloat StartTan_t(int ii, int jj) {
     return( (1-tension)*(P[2][jj][ii] - P[0][jj][ii])/2 );
}
 
GLfloat EndTan_t(int ii, int jj) {
     return( (1-tension)*(P[3][jj][ii] - P[1][jj][ii])/2 );
} 

void Spline_s(int piece_s, int piece_e) {
     double t, vv[3];
     double inc;
     inc = NUMSTEPS;

     for(int j=piece_s-1; j<piece_e; j++) {
          glBegin(GL_LINE_STRIP);
               for(t=0; t<=1; t+=inc) {
                    for(int i=0; i<3; i++) {
                         vv[i] = ((2*t*t*t)-(3*t*t)+1)*StartPt_s(i,j) + ((-2*t*t*t)+(3*t*t))*EndPt_s(i,j)
                              + ((t*t*t)-(2*t*t)+t)*StartTan_s(i,j)  + ((t*t*t)-(t*t))*EndTan_s(i,j);
                    }
                    glColor3d(1.0,1.0,1.0);
                    glVertex3dv(vv);
               }
          glEnd();
     }
}

void Spline_t(int piece_s,int piece_e) {
     double t, vv[3];
     double inc;
     inc = NUMSTEPS;

     for(int j=piece_s-1; j<piece_e; j++) {
          glBegin(GL_LINE_STRIP);
               for(t=0; t<1; t+=inc) {
                    for(int i=0; i<3; i++) {
                         vv[i] = ((2*t*t*t)-(3*t*t)+1)*StartPt_t(i,j)+((-2*t*t*t)+(3*t*t))*EndPt_t(i,j)
                              + ((t*t*t)-(2*t*t)+t)*StartTan_t(i,j) +((t*t*t)-(t*t))*EndTan_t(i,j);
                    }
                    glColor3d(1.0,1.0,1.0);
                    glVertex3dv(vv);
               }
          glEnd();
     }
}

void Spline_Grid() {
     Spline_s(2, 3);
     Spline_t(2, 3);
}

GLfloat B[4][4][3];

void convert(int ii) {
     GLfloat p00 = StartPt_s(ii,1);
     GLfloat p01 = EndPt_s(ii,1);
     GLfloat p10 = EndPt_t(ii,1);
     GLfloat p11 = EndPt_t(ii,2);
     GLfloat p00s = StartTan_t(ii,1);
     GLfloat p01s = EndTan_t(ii,1);
     GLfloat p10s = StartTan_t(ii,2);
     GLfloat p11s = EndTan_t(ii,2);
     GLfloat p00t = StartTan_s(ii,1);
     GLfloat p01t = EndTan_s(ii,1);
     GLfloat p10t = StartTan_s(ii,2);
     GLfloat p11t = EndTan_s(ii,2);

     GLfloat g[] = {p00, p10, p00s, p10s,
                   p01, p11, p01s, p11s,
                   p00t, p10t, 0.0f, 0.0f,
                   p01t, p11t, 0.0f, 0.0f};
     GLfloat m[16];

     glMatrixMode(GL_MODELVIEW);
     glLoadMatrixf (SM);
     glMultMatrixf (g);
     glMultMatrixf (MT);
     glGetFloatv(GL_MODELVIEW_MATRIX, m);

     for(int i=0; i<4; i++) {
          for(int j=0; j<4; j++) {
               B[i][j][ii]=m[4*i+j];
          }
     }
}

void Bvertex() {
     for(int i = 0; i < 3; i++) {
          convert(i);
     }

     glLoadIdentity();
}

void initlights() {
     GLfloat ambient[] = {0.2, 0.2, 0.2, 1.0};
     GLfloat position[] = {10.0, 0.0, 12.0, 1.0};
     GLfloat mat_diffuse[] = {0.6, 0.6, 0.6, 1.0};
     GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0};
     GLfloat mat_shininess[] = {50.0};

     glEnable(GL_LIGHTING);
     glEnable(GL_LIGHT0);

     glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
     glLightfv(GL_LIGHT0, GL_POSITION, position);

     glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
     glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
     glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

void MyInit() {
     Bvertex();
     glClearColor (0.0, 0.0, 0.0, 0.0);
     glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4, &B[0][0][0]);
     glEnable(GL_MAP2_VERTEX_3);
     glMapGrid2f(100, 0.0, 1.0, 100, 0.0, 1.0);
     glEnable(GL_DEPTH_TEST);
     glShadeModel(GL_FLAT);
     glEnable(GL_LINE_SMOOTH);
     glEnable(GL_POINT_SMOOTH); 
     //initlights();                // For Lighted and Filled Hermite Spline Surface
}

void MyDisplay() {
     glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();

     glColor3f(0.0, 0.0, 0.0);

     glPushMatrix ();
          glRotatef(10.0, 1.0, 1.0, 1.0);
          glEvalMesh2(GL_FILL, 0, 100, 0, 100);
          glColor3f(0.0, 1.0, 0.0);
          glLineWidth(1.0);

          for (int j = 0; j <= 8; j++) {
               glBegin(GL_LINE_STRIP);
                    for (int i = 0; i <= 100; i++)
                         glEvalCoord2f((GLfloat)i/100.0, (GLfloat)j/8.0);
               glEnd();
               glBegin(GL_LINE_STRIP);
                    for (int i = 0; i <= 100; i++)
                         glEvalCoord2f((GLfloat)j/8.0, (GLfloat)i/100.0);
               glEnd();
          }

//        Spline_Grid();
          glPopMatrix ();
/*
          glDisable(GL_LIGHTING);
          glColor3f(1.0, 0.0, 0.0);
          glPointSize(3);
          glBegin(GL_POINTS);
               for(int i=0; i!=4; ++i) {
                    for(int j=0; j!=4; ++j) {
                         glVertex3fv(P[i][j]);
                    }
               }
     glEnd();
*/
     glFlush(); 
}

void MyReshape(GLsizei w, GLsizei h) {
     glViewport(0, 0, w, h);
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();

     if (w <= h)
          glOrtho(-5.0, 5.0, -5.0*(GLfloat)h/(GLfloat)w, 5.0*(GLfloat)h/(GLfloat)w, -20.0, 20.0);
     else
          glOrtho(-5.0*(GLfloat)w/(GLfloat)h, 5.0*(GLfloat)w/(GLfloat)h, -5.0, 5.0, -20.0, 20.0);

     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();
}

int main(int argc, char** argv) { 
     glutInit(&argc, argv);
     glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
     glutInitWindowSize (640, 480); 
     glutInitWindowPosition (100, 100);
     glutCreateWindow ("Hermite Spline Surface");
     MyInit();
     glutDisplayFunc(MyDisplay);
     glutReshapeFunc(MyReshape);

     glutMainLoop();
     return 0;
}