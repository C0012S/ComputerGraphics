#include <Windows.h>
#include <stdlib.h>
#include <glu.h>
#include <glut.h>

static POINT ptLastMousePosit;
static POINT ptCurrentMousePosit;
static bool bMousing;

float g_fDistance = -20.0f;
float g_fSpinX    = 0.0f;
float g_fSpinY    = 0.0f;

// NURBS object pointer
GLUnurbsObj *pNurb = NULL;

// The number of control points for this curve
GLint nNumPoints = 4; // 4 X 4

// Mesh extends four units -6 to +6 along x and y axis
// Lies in Z plane
//                 u  v  (x,y,z)	
GLfloat ctrlPoints[4][4][3]= {{{  -6.0f, -6.0f, 0.0f},	// u = 0,	v = 0
                              {	  -6.0f, -2.0f, 0.0f},	//			v = 1
                              {   -6.0f,  2.0f, 0.0f},	//			v = 2	
                              {   -6.0f,  6.0f, 0.0f}}, //			v = 3
							 
                             {{  -2.0f, -6.0f, 0.0f},	// u = 1	v = 0
                              {   -2.0f, -2.0f, 8.0f},	//			v = 1
                              {   -2.0f,  2.0f, 8.0f},	//			v = 2
//                            {   -2.0f, -2.0f, 0.0f},	//			v = 1
//                            {   -2.0f,  2.0f, 0.0f},	//			v = 2
                              {   -2.0f,  6.0f, 0.0f}},	//			v = 3
							  
                             {{   2.0f, -6.0f, 0.0f }, // u =2		v = 0
                              {    2.0f, -2.0f, 8.0f }, //			v = 1
                              {    2.0f,  2.0f, 8.0f },	//			v = 2
//                            {    2.0f, -2.0f, 0.0f }, //			v = 1
//                            {    2.0f,  2.0f, 0.0f },	//			v = 2
                              {    2.0f,  6.0f, 0.0f }},//			v = 3

                             {{   6.0f, -6.0f, 0.0f},	// u = 3	v = 0
                              {    6.0f, -2.0f, 0.0f},	//			v = 1
                              {    6.0f,  2.0f, 0.0f},	//			v = 2
                              {    6.0f,  6.0f, 0.0f}}};//			v = 3

// Knot sequence for the NURB
GLfloat Knots[8] = {0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f};

// Called to draw the control points in Red over the NURB
void DrawPoints(void) {
    // Large Red Points
    glPointSize(5.0f);
    glColor3ub(255,0,0);

    // Draw all the points in the array
    glBegin(GL_POINTS);
        for(int i = 0; i < 4; i++)
            for(int j = 0; j < 4; j++)
                glVertex3fv(ctrlPoints[i][j]);	
    glEnd();
}

// Called to draw scene
void RenderScene(void) {
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

    glTranslatef( 0.0f, 0.0f, g_fDistance );
    glRotatef( -g_fSpinY, 1.0f, 0.0f, 0.0f );
    glRotatef( -g_fSpinX, 0.0f, 1.0f, 0.0f );

    // Draw in Blue
    glColor3ub(0,0,220);

    glPushMatrix();
		// Rotate the mesh around to make it easier to see
		glRotatef(330.0f, 1.0f,0.0f,0.0f);
	
		// Render the NURB
		// Begin the NURB definition
		gluBeginSurface(pNurb);
	
		// Evaluate the surface
		gluNurbsSurface(pNurb,	// pointer to NURBS renderer
			8, Knots,			// No. of knots and knot array u direction	
			8, Knots,			// No. of knots and knot array v direction
			4 * 3,				// Distance between control points in u dir.
			3,					// Distance between control points in v dir.
			&ctrlPoints[0][0][0], // Control points
			4, 4,					// u and v order of surface
			GL_MAP2_VERTEX_3);		// Type of surface
		
		// Done with surface
		gluEndSurface(pNurb);
	
		// Show the control points
		DrawPoints();

	// Restore the modelview matrix
	glPopMatrix();

    // Dispalay the image
    glutSwapBuffers();
}

// This function does any needed initialization on the rendering
// context.  Here it sets up and initializes the lighting for
// the scene.
void SetupRC() {
    // Light values and coordinates
    GLfloat  whiteLight[] = {0.7f, 0.7f, 0.7f, 1.0f };
    GLfloat  specular[] = { 0.7f, 0.7f, 0.7f, 1.0f};
    GLfloat  shine[] = { 100.0f };

    // Clear Window to white
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f );

    // Enable lighting
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    // Enable color tracking
    glEnable(GL_COLOR_MATERIAL);
	
    // Set Material properties to follow glColor values
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shine);
	
    // Automatically generate normals for evaluated surfaces
    glEnable(GL_AUTO_NORMAL);

    // Setup the Nurbs object
    pNurb = gluNewNurbsRenderer();

    gluNurbsProperty(pNurb, GLU_SAMPLING_TOLERANCE, 25.0f);
    // Uncomment the next line and comment the one following to produce a
    // wire frame mesh.
    //gluNurbsProperty(pNurb, GLU_DISPLAY_MODE, GLU_OUTLINE_POLYGON);
    gluNurbsProperty(pNurb, GLU_DISPLAY_MODE, (GLfloat)GLU_FILL);
}

void MyReshape(int w,int h) {    
	glViewport(0,0,w,h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

    gluPerspective (45, (GLfloat)w / (GLfloat)h, 0.1, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void MySpecial(int key, int x, int y) {
	if(key == GLUT_KEY_PAGE_UP) {
		g_fDistance -= 1.0f;
	} else if(key == GLUT_KEY_PAGE_DOWN) {
		g_fDistance += 1.0f;
	}

	glutPostRedisplay();
}

void MyMouse(int button, int state, int x, int y) {
   switch (button) {
      case GLUT_LEFT_BUTTON:
         if (state == GLUT_DOWN) {
            ptLastMousePosit.x = ptCurrentMousePosit.x = x;
            ptLastMousePosit.y = ptCurrentMousePosit.y = y;
            bMousing = true;
		 } else 
			bMousing = false;
         break;
      case GLUT_MIDDLE_BUTTON:
      case GLUT_RIGHT_BUTTON:
         break;
      default:
         break;
   }

   glutPostRedisplay();
}

void MyMotion(int x, int y) {
	ptCurrentMousePosit.x = x;
    ptCurrentMousePosit.y = y;

    if( bMousing )
    {
		g_fSpinX -= (ptCurrentMousePosit.x - ptLastMousePosit.x);
        g_fSpinY -= (ptCurrentMousePosit.y - ptLastMousePosit.y);
    }

    ptLastMousePosit.x = ptCurrentMousePosit.x;
    ptLastMousePosit.y = ptCurrentMousePosit.y;

    glutPostRedisplay();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
	glutCreateWindow("NURBS Surface");

	glutReshapeFunc(MyReshape);
	glutDisplayFunc(RenderScene);
	glutMouseFunc(MyMouse);
	glutMotionFunc(MyMotion);
	glutSpecialFunc(MySpecial);
	SetupRC();

	glutMainLoop();
	return 0;
}